import PaperIII.ProblemAdequacy
import PaperIII.Capacity
import PaperIII.Revision
import PaperIII.Principalhood
import PaperIII.NonCollapse
import PaperIII.Models
import PaperIII.GovernedMachine
import PaperIII.HumanAuthority
