# Paper III structural supplement — 3 October 2026

The bundled `reports/paper_iii_reproduction_20261003.zip` is the unchanged 69-declaration Lean core. Extract it separately and use its pinned Lean 4.29.0 and dependency configuration. Run `lake build PaperIII` and `lake env lean scripts/AuditPaperIII.lean`. Its source ID is recorded in `reports/paper_iii_revision_artifact.json`.

From this supplement's extraction directory, run `python3 manuscripts/restructure/check_paper_iii_finite.py` for the new joint episode. It is an exhaustive Python model check, not a joint Lean theorem or an empirical study. The generated JSON contains all four complete traces and the state/transition counts.

Regenerate the architecture figure with `python3 manuscripts/restructure/draw_paper_iii_architecture.py`, requiring ReportLab, the DejaVu fonts and pdftoppm. Figure sources and both vector and print-resolution outputs are included. The manifest gives SHA-256 hashes of every included file.

This is a local supplement. No public deposition, DOI, or journal supplementary upload is claimed.
